# SAFE-AI

SAFE-AI is a prototype postoperative monitoring and clinical decision-support web application.

## What this prototype contains
- Python FastAPI backend
- JSON REST API
- Clinical team dashboard
- Patient-facing recovery app
- Synthetic demo patients only
- CoReAL-derived dynamic prediction adapter structure
- `/health`, `/api/status`, `/docs`, and `/openapi.json`

## Important model note
The web application is wired around the current CoReAL dynamic landmark-model design:
preoperative, end-of-operation, POD1, POD3, and POD5.

The actual trained CoReAL coefficients / serialized model weights are **not embedded in this prototype**.
Until those model artifacts are connected, prediction values are deterministic synthetic demo values and
are explicitly labelled `mock`. The application must not present these as clinically validated predictions.

## Run
```bash
pip install -r requirements.txt
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

Open:
- App: http://127.0.0.1:8000
- Clinical: http://127.0.0.1:8000/clinical
- Patient: http://127.0.0.1:8000/patient
- Health: http://127.0.0.1:8000/health
- API docs: http://127.0.0.1:8000/docs
- OpenAPI JSON: http://127.0.0.1:8000/openapi.json

## Demo login
No authentication is enabled in this first UI prototype. Authentication is represented as a future backend layer.

## Deployment
This repository is ready to deploy on Replit with:
`uvicorn app.main:app --host 0.0.0.0 --port 8000`

Do not use real patient data in this prototype.
