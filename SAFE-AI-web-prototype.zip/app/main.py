from pathlib import Path
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from .models import PatientSummary, RecoveryCheckIn, AlertAction
from .data import PATIENTS, CHECKINS
from .prediction import prediction_adapter

BASE = Path(__file__).resolve().parent
STATIC = BASE / "static"

app = FastAPI(
    title="SAFE-AI API",
    version="0.1.0",
    description="SAFE-AI postoperative monitoring prototype. Synthetic demo data only."
)

app.mount("/static", StaticFiles(directory=STATIC), name="static")

@app.get("/", include_in_schema=False)
def root():
    return FileResponse(STATIC / "index.html")

@app.get("/clinical", include_in_schema=False)
def clinical():
    return FileResponse(STATIC / "clinical.html")

@app.get("/patient", include_in_schema=False)
def patient():
    return FileResponse(STATIC / "patient.html")

@app.get("/health")
def health():
    return {"status": "ok", "service": "SAFE-AI API", "version": "0.1.0"}

@app.get("/api/status")
def status():
    return {
        "api": "online",
        "database": "synthetic in-memory demo",
        "prediction_service": "mock CoReAL landmark adapter",
        "environment": "development"
    }

@app.get("/api/v1/patients", response_model=list[PatientSummary])
def list_patients():
    return [
        {
            "patient_id": p["patient_id"],
            "display_name": p["display_name"],
            "age": p["age"],
            "procedure": p["procedure"],
            "postoperative_day": p["postoperative_day"],
            "ward": p["ward"],
            "overall_risk": p["overall_risk"],
            "risk_category": p["risk_category"],
            "trend": p["trend"],
            "active_alerts": p["active_alerts"],
        }
        for p in PATIENTS
    ]

@app.get("/api/v1/patients/{patient_id}")
def patient_detail(patient_id: str):
    p = next((x for x in PATIENTS if x["patient_id"] == patient_id), None)
    if not p:
        raise HTTPException(status_code=404, detail="Patient not found")
    return p

@app.get("/api/v1/patients/{patient_id}/prediction")
def patient_prediction(patient_id: str):
    pred = prediction_adapter.get_prediction(patient_id)
    if not pred:
        raise HTTPException(status_code=404, detail="Patient not found")
    return pred

@app.post("/api/v1/recovery-checkins")
def submit_checkin(checkin: RecoveryCheckIn):
    item = checkin.model_dump()
    item["status"] = "recorded"
    CHECKINS.append(item)
    return {
        "status": "recorded",
        "message": "Recovery check-in recorded.",
        "patient_id": checkin.patient_id,
        "model_update": "demo-only"
    }

@app.post("/api/v1/alerts/action")
def alert_action(action: AlertAction):
    for p in PATIENTS:
        for alert in p["alerts"]:
            if alert["id"] == action.alert_id:
                alert["status"] = action.action
                return {
                    "status": "ok",
                    "alert_id": action.alert_id,
                    "new_status": action.action,
                    "user": action.user
                }
    raise HTTPException(status_code=404, detail="Alert not found")
