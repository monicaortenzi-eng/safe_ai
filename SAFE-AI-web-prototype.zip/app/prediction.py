from datetime import datetime, timezone
from .data import PATIENTS

class CoreALPredictionAdapter:
    """
    Adapter for the current CoReAL landmark-model architecture.

    Current CoReAL research design:
      - landmarks: preoperative, end of operation, POD1, POD3, POD5
      - model families: L2-penalized logistic regression and random forest
      - numeric preprocessing: training-fold median imputation + missingness indicators + scaling
      - categorical preprocessing: explicit missing category + one-hot encoding
      - no SMOTE in the current model

    IMPORTANT:
    The serialized trained CoReAL model artifacts are not bundled here.
    Until those are supplied, this adapter returns deterministic synthetic demo predictions
    already stored for each fictional patient. It must not be used clinically.
    """

    model_mode = "mock"
    model_family = "CoReAL landmark adapter — L2 logistic regression / random forest"

    def get_prediction(self, patient_id: str):
        p = next((x for x in PATIENTS if x["patient_id"] == patient_id), None)
        if not p:
            return None
        return {
            "prediction_id": f"DEMO-{patient_id}-{p['landmark']}",
            "patient_id": patient_id,
            "landmark": p["landmark"],
            "overall_risk": p["overall_risk"],
            "risk_category": p["risk_category"],
            "previous_risk": p["previous_risk"],
            "complication_risks": p["complications"],
            "model_family": self.model_family,
            "model_mode": self.model_mode,
            "updated_at": datetime.now(timezone.utc).isoformat(),
            "contributing_factors": p["factors"],
        }

prediction_adapter = CoreALPredictionAdapter()
