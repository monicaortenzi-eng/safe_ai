from pydantic import BaseModel, Field
from typing import List, Optional

class ComplicationRisk(BaseModel):
    name: str
    probability: float = Field(ge=0, le=1)
    trend: str

class Prediction(BaseModel):
    prediction_id: str
    patient_id: str
    landmark: str
    overall_risk: float = Field(ge=0, le=1)
    risk_category: str
    previous_risk: Optional[float] = None
    complication_risks: List[ComplicationRisk]
    model_family: str
    model_mode: str
    updated_at: str
    contributing_factors: List[str] = []

class PatientSummary(BaseModel):
    patient_id: str
    display_name: str
    age: int
    procedure: str
    postoperative_day: int
    ward: str
    overall_risk: float
    risk_category: str
    trend: str
    active_alerts: int

class RecoveryCheckIn(BaseModel):
    patient_id: str
    pain: int = Field(ge=0, le=10)
    temperature_c: float = Field(ge=30, le=45)
    intake: str
    nausea_or_vomiting: bool
    mobility: str
    wound_concern: bool
    shortness_of_breath: bool = False
    notes: str = ""

class AlertAction(BaseModel):
    alert_id: str
    action: str
    user: str
